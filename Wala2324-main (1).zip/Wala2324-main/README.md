Hej jag är Wala och det är min figma desig
https://www.figma.com/design/LjJTZpE9mlJjsKwPN0YwJR/Untitled?t=rnqZNj2MLPRR9M9y-1
